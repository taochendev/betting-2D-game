import React, {useEffect, useState} from 'react';
import './Assets/CSS/App.scss';
import './Assets/CSS/Leaderboard.scss';
import './Assets/CSS/Challenges.scss';
import './Assets/CSS/Challenges.responsive.scss';
import './Assets/CSS/featuredInfo.scss';
import './Assets/CSS/Giveaways.scss';
import './Assets/CSS/Giveaways.responsive.scss';
import './Assets/CSS/App.responsive.scss';
import './Assets/CSS/Profile.scss';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import {axiosGet} from "./Utility/httpClient";
import {AccountPlayerOverview, AccountProfile, PlayerDetails, TwitchAuthCodeGrantFlow} from "./API/api";
import CloseIcon from '@mui/icons-material/Close';
import HomeIcon from '@mui/icons-material/Home';
import {Cake, EmojiEvents, People} from "@material-ui/icons";
import {MilitaryTech, PrecisionManufacturing} from "@mui/icons-material";
import {PlayCrash} from "./Routes/Play/PlayCrash";
import {accountEvents} from "./Utility/serverEventSource";

const getDetails = async (): Promise<PlayerDetails> => axiosGet(`/auth/details`)
const getProfile = async (): Promise<AccountProfile> => axiosGet(`/auth/profile`)
const getProfileBalance = async (username: string): Promise<AccountPlayerOverview> => axiosGet(`/auth/player-overview?username=${username}`)
const getAccessToken = async (code: string): Promise<TwitchAuthCodeGrantFlow> => axiosGet(`/auth/discord?code=${code}`)
const setCurrentProfileServer = async (name: string): Promise<AccountProfile> => axiosGet(`/auth/current-profile?profile=${name}`)

export default function App() {
    const [open, setOpen] = React.useState<boolean>(true)
    const [details, setDetails] = React.useState<PlayerDetails | undefined>(undefined)
    const [profile, setProfile] = useState<AccountProfile | undefined>(undefined);
    const [currentBalance, setCurrentBalance] = useState<number>(0);
    const [balanceOverview, setBalanceOverview] = useState<AccountPlayerOverview | undefined>(undefined);

    const [panelVisible, setPanelVisible ] = React.useState<boolean>(true)
    const hasToken = localStorage.getItem("bearer")

    async function checkDiscordLogin() {
        const url = window.location.href;
        const codeMatches = url.match(/code=([^&]*)/);
        const errorMatches = url.match(/error=([^&]*)/);
        let code = undefined;
        let error = undefined;
        const hasToken = localStorage.getItem("bearer") != null;
        if (codeMatches) {
            code = codeMatches[0].substring(5);
        } else if (errorMatches) {
            error = errorMatches[0].substring(6);
        }
        if (code) {
            if (hasToken) {
                localStorage.removeItem("bearer");
                localStorage.removeItem("refresh");
                localStorage.removeItem("expiry");
            }
            localStorage.setItem("twitch", code);
            await fetchToken();
            //@ts-ignore
            window.location.href = process.env.REACT_APP_TWITCH_REDIRECT_URI;
        } else if (error) {
            if (hasToken) {
                localStorage.removeItem("bearer");
                localStorage.removeItem("refresh");
                localStorage.removeItem("expiry");
            }
        } else if (hasToken) {
            if (localStorage.getItem("bearer")!.toString().length > 0) {
                getDetails().then((response: PlayerDetails) => {
                    setUserDetails(response)
                }).catch(err => {
                    localStorage.removeItem("bearer");
                    localStorage.removeItem("refresh");
                    localStorage.removeItem("expiry");
                })
            }
        }
    }

    async function fetchToken() {
        while (localStorage.getItem("bearer") == null || localStorage.getItem("bearer")!.length == 0) {
            await getAccessToken(localStorage.getItem("twitch")!).then(response => {
                localStorage.setItem("bearer", response.access_token);
                localStorage.setItem("refresh", response.refresh_token);
                localStorage.setItem("expiry", `${response.expires_in}`);
            });
        }
    }

    const [userDetails, setUserDetails] = useState<PlayerDetails | undefined>(undefined);
    const [warning, setWarning] = useState<string | undefined>(undefined);
    const [warningOpen, setWarningOpen] = useState<boolean>(false);

    useEffect(() => {
        checkDiscordLogin()
    }, [])

    useEffect(() => {
        if (hasToken) {
            getDetails().then(r => loadCurrentProfile(r)).catch(e => {
                localStorage.removeItem("bearer")
                window.location.href = "https://discord.com/oauth2/authorize?client_id=1268301726012936352&redirect_uri=http://localhost:3000/&response_type=code&scope=identify&prompt=none"
            })
        } else {
                window.location.href = "https://discord.com/oauth2/authorize?client_id=1268301726012936352&redirect_uri=http://localhost:3000/&response_type=code&scope=identify&prompt=none"
            }
    }, [])

    const loadCurrentProfile = (r: PlayerDetails) => {
        setDetails(r)
        getProfile().then(r => {
            setProfile(r)
        }).catch(r => window.location.href='https://dragonsden.gg/')
        getProfileBalance(r.currentProfile.replaceAll(' ', '_')).then(r => {
            setBalanceOverview(r)
            setCurrentBalance(r.held)
        })
        accountEvents(r.currentProfile.replaceAll(' ', '_'), (username: string, balance: number) => {
            setCurrentBalance(balance)
            getDetails().then(r => setDetails(r)).catch(e => {})
        })
    }

    const setCurrentProfile = (profile: string) => {
        setCurrentProfileServer(profile.replaceAll(" ", "_")).then(pr => {
            getDetails().then(r => loadCurrentProfile(r)).catch(e => {
//                 localStorage.removeItem("bearer")
//                 window.location.reload()
            })
        })
    }

    const toggleSelector = panelVisible ? '' : 'Navigation-Items-Mobile';
    if (!details) {
        return (
            <div className="App">
                <div className="App-contents-container">
                </div>
            </div>)
    }
    return (
        <div className="App">
            <div className="App-contents-container"
                 key={details?.currentProfile ?? 'loggedout'}
            >
                <BrowserRouter>
                    <Routes>
                        <Route element={
                            <PlayCrash
                                accountDetails={details}
                                setCurrentProfile={setCurrentProfile}
                                profileDetails={profile}
                                balanceOverview={balanceOverview}
                                currentBalance={currentBalance}
                            />
                        } path="/crash"/>
                    </Routes>
                </BrowserRouter>
            </div>
        </div>
    );


}

