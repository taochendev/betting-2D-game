import '../../Assets/CSS/Editor.scss'
import React, {useEffect, useState} from "react";
import {useParams} from 'react-router-dom';
import {getLoadingBar} from "../../Utility/loadingBar";
import {toRuneScapeFormatFromExact} from "../../Utility/utils";
import Crash from "../../Games/Crash/Crash";
import {faVolumeHigh, faVolumeMute} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

export const PlayCrash: React.FC<any> = ({
    accountDetails,
    setCurrentProfile,
    profileDetails,
    balanceOverview,
    currentBalance
}) => {

    const params = useParams();
    const [openLinkGuide, setOpenLinkGuide] = useState(false);
    const [muted, setMuted] = useState(localStorage.getItem('mute-sounds') == "true");

    useEffect(() => {
        if (!muted) {
            localStorage.removeItem('mute-sounds');
        } else {
            localStorage.setItem('mute-sounds', "true");
        }
    }, [muted])

    const getCurrentView = () => {
        return (<div className="Current-Tier-Container">
            {getAccountsView()}
        </div>)
    }

    function getAccountsView() {
        return <div className="OSRSAccount OSRSAccountGames">
            { balanceOverview ? (<div className="OSRSAccountSection OSRSAccountSectionGames">
                    <div className="OSRSAccountSectionExpandedHeader">
                        <div className="Heading">
                            <img src="/rocket.svg"/>
                            <h3>Crash</h3>
                            <a onClick={() => setMuted(!muted)}><FontAwesomeIcon icon={muted ? faVolumeMute : faVolumeHigh} /></a>
                            <a>|</a>
                            <span>{toRuneScapeFormatFromExact(currentBalance)} GP</span>
                        </div>
                        <div className="OSRSAccountsBar OSRSAccountsBarExpanded">
                            <select defaultValue={accountDetails?.currentProfile} onChange={e => {
                                setCurrentProfile(e.target.value)
                            }}>
                                { profileDetails.accounts.map((c: any) => (<option value={c}>{c}</option>)) }
                            </select>
                        </div>
                    </div>

                    <Crash
                        balance={currentBalance}
                        setBalance={() => {}}
                        username={balanceOverview.username}
                        currency={'OSRS'}
                        warn={false}
                    />

                </div>) :
                (<div className="OSRSAccountSection">
                    <div className="Heading">
                        <img src="/rocket.svg"/>
                        <h3>Crash</h3>
                        <span>Loading...</span>
                    </div>
                    <div className="Loader-bar-space">
                        {getLoadingBar(true, "Fetching Information...")}
                    </div>
                </div>)
            }

        </div>
    }

    if (!profileDetails) {
        return (<>
            <div className="ProfileView"></div>
        </>)
    }
    return (<>
        <div className="App-contents">
            <div className="Landing-conten ProfileView">
                <div className="CurrentView">
                    {getCurrentView()}
                </div>
                <br/><br/><br/><br/><br/><br/>
            </div>
        </div>

    </>)
}
